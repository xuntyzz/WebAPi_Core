﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WEBAPI_Core1.Data;
using WEBAPI_Core1.Models;

namespace WEBAPI_Core1.Helpers
{
    public class ApplicationMapper : Profile
    {
        public ApplicationMapper() => CreateMap<Books, BookModel>().ReverseMap();
    }
}
