﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using WEBAPI_Core1.Models;
using WEBAPI_Core1.Repository;

namespace WEBAPI_Core1.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private readonly IAccountRepository _accountRepository;

        public AccountsController(IAccountRepository accountRepository) => _accountRepository = accountRepository;

        [HttpPost]
        public async Task<IActionResult> SignUpAsync ([FromBody] SignUpModel signUp)
        {
            var result = await _accountRepository.SignUpAsync(signUp);

            return result.Succeeded ? Ok("Signup Completed Sucessfully !!") : Unauthorized();
        }
    }
}
