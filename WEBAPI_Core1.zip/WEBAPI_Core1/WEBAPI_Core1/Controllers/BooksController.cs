﻿using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using WEBAPI_Core1.Models;
using WEBAPI_Core1.Repository;

namespace WEBAPI_Core1.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IBookRepository _bookRepository;

        public BooksController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetAllBooks()
        {
            var books = await _bookRepository.GetAllBooksAsync();

            return Ok(books);
        }

        [HttpGet]
        public async Task<IActionResult> GetBookById([FromBody] int id)
        {
            var books = await _bookRepository.GetBookByIdAsync(id);

            if (books == null)
            {
                return NotFound();
            }

            return Ok(books);
        }

        [HttpPost]
        public async Task<IActionResult> AddBook([FromBody] BookModel data)
        {
            var books = await _bookRepository.AddBookAsync(data);

            return CreatedAtAction(nameof(GetBookById), new { id = books, controller = "books" });
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> UpdateBook([FromBody] BookModel data, [FromRoute]int Id)
        {
            await _bookRepository.UpdateBookAsync(data, Id);

            return Ok($"{data.Title} Updated Successfully !!");
        }

        [HttpPatch("{Id}")]
        public async Task<IActionResult> UpdateBookPatch([FromBody] JsonPatchDocument data, [FromRoute]int Id)
        {
            await _bookRepository.UpdateBookPatchAsync(data, Id);
            return Ok($"Updated Successfully !!");
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteBook([FromBody] int bookId)
        {
            await _bookRepository.DeleteBookAsync(bookId);
            return Ok("Entry Deleted Successfully !!");
        }
    }
}
