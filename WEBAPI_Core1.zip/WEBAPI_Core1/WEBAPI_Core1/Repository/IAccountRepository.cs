﻿using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using WEBAPI_Core1.Models;

namespace WEBAPI_Core1.Repository
{
    public interface IAccountRepository
    {
        Task<IdentityResult> SignUpAsync(SignUpModel signUp);
    }
}
