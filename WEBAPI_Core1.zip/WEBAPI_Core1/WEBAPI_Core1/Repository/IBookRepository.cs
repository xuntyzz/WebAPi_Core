﻿using Microsoft.AspNetCore.JsonPatch;
using System.Collections.Generic;
using System.Threading.Tasks;
using WEBAPI_Core1.Data;
using WEBAPI_Core1.Models;

namespace WEBAPI_Core1.Repository
{
    public interface IBookRepository
    {
        Task<List<BookModel>> GetAllBooksAsync();

        Task<BookModel> GetBookByIdAsync(int id);

        Task<int> AddBookAsync(BookModel data);

        Task UpdateBookAsync(BookModel book, int bookId);

        Task UpdateBookPatchAsync(JsonPatchDocument book, int bookId);

        Task DeleteBookAsync(int bookId);
    }
}
